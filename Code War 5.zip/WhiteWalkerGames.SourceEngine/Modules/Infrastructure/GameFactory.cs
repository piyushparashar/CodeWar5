﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhiteWalkersGames.SourceEngine.Modules.Infrastructure
{
    public interface IGame
    {
        void Start();

        void Restart();
    }

    public interface IGameHost
    {
        void CreateGame(IGameContext context);

        void StartGame();

        void RestartGame();


    }

    public interface IGameContext
    {
        
    }

    public class GameFactory
    {

    }
}
